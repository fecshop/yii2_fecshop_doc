协议
=========

* 本作品继承并同时支持针对官方及用户贡献文本所指定的 **[GNU Free Documentation License (GFDL)协议](http://www.gnu.org/copyleft/fdl.html)**。

* 其他的周边衍生作品采用 **知识共享 署名-相同方式共享 4.0 国际 许可协议**进行许可。你可以访问 [CC-4.0-DEED-中文](http://creativecommons.org/licenses/by-sa/4.0/deed.zh) 查看该协议。

* 对于 Yii 的各项协议的更多详细说明，请前往 [www.yiiframework.com/license](http://www.yiiframework.com/license/) 了解更多内容。

* 我们鼓励大家贡献基于以上述协议的自制教程，当然如果你一定要用 [WTFPL](zh.wikipedia.org/zh/WTFPL) 我们也不管你哦，O(∩_∩)O哈哈~

GNU Free Documentation License (GFDL) 协议具体内容
--------

###必须：

* 授予使用者与原协议完全相同的自由权（CopyLeft什么意思，你们都懂得）
* 通过一个指向源文件的连接明示原作者

###可以：

* 复制
* 修改
* 再分发