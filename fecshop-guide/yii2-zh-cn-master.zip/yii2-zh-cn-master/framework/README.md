Yii PHP 框架版本2
===========================
> 翻译日期：20140504

本目录是[Yii 2](https://github.com/yiisoft/yii2#readme)的核心框架代码。


安装
------------

Yii 框架的首选安装方式是[composer](http://getcomposer.org/download/)。

运行

```
php composer.phar require --prefer-dist "yiisoft/yii2 *"
```

或添加

```json
"yiisoft/yii2": "*"
```

到你的 composer.json 文件的 require 部分。
