内部文档索引
==========

开发相关
-------

* 【已校对-20140121】 [反馈问题](report-an-issue.md)
* 【已校对-20141023】 [开始进行 Yii2 开发](getting-started.md)
* 【已校对-20141023】 [git 工作流程（workflow）](git-workflow.md)
* 【已校对-20140905】 [核心代码风格指南](core-code-style.md)
* 【已校对-20140620】 [Yii2 视图代码风格](view-code-style.md)
* 【已校对-20140501】 [自动化操作](automation.md)
* 【非文本-20130511】 [异常的结构](exception_hierarchy.png)

翻译相关
-------

* 【已校对-20141006】 [翻译工作流](translation-workflow.md)
* 【已校对-20141006】 [文档状态（是否允许翻译）](translation-status.md)
* 【已校对-20141013】 [翻译团队](translation-teams.md)
* 【已校对-20120503】 [错误和异常](errors_and_exceptions.md)

组织说明
-------

* 【已校对-20141018】 [Yii 版本发布规则](getting-started.md)