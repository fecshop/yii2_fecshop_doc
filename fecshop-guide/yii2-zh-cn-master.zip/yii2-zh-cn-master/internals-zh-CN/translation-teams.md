Translation teams
=================

Brazilian Portuguese
--------------------

- **[@wbraganca](https://github.com/wbraganca)**
- Alan Michel Willms Quinot, [@alanwillms](https://github.com/alanwillms), dyulax@gmail.com

China
-----

- **Paris Qian Sen 东方孤思子,[@qiansen1386](https://github.com/qiansen1386),qiansen1386@gmail.com**
- [@AbrahamGreyson 刘阳](https://github.com/AbrahamGreyson)
- [@Aliciamiao](https://github.com/aliciamiao)
- [@funson86 花生](https://github.com/funson86)
- [@netyum 未来](https://github.com/netyum)
- [@riverlet 小河](https://github.com/riverlet)
- [@yiichina 巡洋舰](https://github.com/yiichina)

Finnish
------

- Jani Mikkonen, [@janisto](https://github.com/janisto), janisto@php.net

German
------

- Carsten Brandt, [@cebe](https://github.com/cebe), mail@cebe.cc

Italian
-------

- Lorenzo Milesi, [@maxxer](https://github.com/maxxer), maxxer@yetopen.it

Japanese
-------

- Nobuo Kihara 木原伸夫, [@softark](https://github.com/softark), softark@gmail.com

Russian
-------

- **Alexander Makarov, [@samdark](https://github.com/samdark), sam@rmcreative.ru**
- [@MUTOgen](https://github.com/MUTOgen)
- [@prozacUa](https://github.com/prozacUa)

Spanish
-------

- Luciano Baraglia, [@lucianobaraglia](https://github.com/lucianobaraglia)
- Marco Da Silva, [@markmarco16](https://github.com/markmarco16), markmarco16@gmail.com
- Daniel Gómez Pan [@pana1990](https://github.com/pana1990), pana_1990@hotmail.com

Ukrainian
---------

- **Alexandr Bordun [@borales](https://github.com/Borales), admin@yiiframework.com.ua**
- Roman Bahatyi [@RichWeber](https://github.com/RichWeber), rbagatyi@gmail.com
